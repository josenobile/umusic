<?
// Close the connection to winamp....
$status->closefp(); 
?> 